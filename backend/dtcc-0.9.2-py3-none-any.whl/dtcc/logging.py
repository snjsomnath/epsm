# Copyright(C) 2023 Anders Logg
# Licensed under the MIT License

from dtcc_core.common import init_logging

debug, info, warning, error, critical = init_logging("dtcc")
